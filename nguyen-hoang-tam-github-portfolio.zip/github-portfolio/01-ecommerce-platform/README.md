# E-commerce Platform Architecture

## Overview

A technical case study based on my recent experience working on an e-commerce platform specializing in furniture, home goods and interior design services.

The platform supports product browsing, search, customer interactions, payments, logistics integrations and AI-powered recommendations.

## Architecture

```text
Users
  |
  v
Cloudflare / Nginx
  |
  v
Node.js / Express.js API
  |
  +--------> MongoDB
  |
  +--------> Redis
  |
  +--------> Elasticsearch
  |
  +--------> Payment / Logistics APIs
  |
  +--------> AI Recommendation Services
```

## Tech Stack

- Backend: Node.js, Express.js, TypeScript
- Frontend: React.js, Next.js
- Database: MongoDB
- Cache: Redis
- Search: Elasticsearch
- Infrastructure: Docker, Nginx
- CI/CD: GitHub Actions
- Cloud: AWS / Viettel Cloud
- AI: AWS Personalize, Vertex AI

## My Role

- Designed and developed RESTful APIs.
- Built frontend components with React.js and Next.js.
- Optimized MongoDB queries and indexes.
- Worked on infrastructure and deployment.
- Integrated payment and logistics services.
- Worked on AI-powered recommendation and interior-design features.

## Engineering Highlight

MongoDB query and indexing optimization reduced product listing API response time from over 2 seconds to under 1 second.

## Confidentiality

This repository is a public technical case study. It intentionally contains no proprietary source code, credentials, customer data or internal business logic.
