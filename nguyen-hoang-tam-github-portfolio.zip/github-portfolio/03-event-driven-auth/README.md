# Event-Driven Authentication Synchronization

## Overview

A technical case study based on work on a large community platform.

The system needed to synchronize user information between a legacy monolithic application and a newer microservices platform.

## Architecture

```text
Legacy Monolith
      |
      | User/Auth Event
      v
   RabbitMQ
      |
      v
Authentication Service
      |
      v
Microservices Platform
```

## Why Event-Driven Architecture?

Instead of tightly coupling the legacy application directly to the new services, events were used as an integration boundary.

This approach helped:

- Decouple systems.
- Process synchronization asynchronously.
- Reduce direct dependencies.
- Allow the new platform to evolve independently.

## Tech Stack

- Node.js
- Express.js
- RabbitMQ
- MySQL
- MongoDB
- Redis
- Elasticsearch
- Docker

## My Role

- Designed the event-driven authentication synchronization service.
- Worked on RESTful APIs and database schemas.
- Integrated the legacy and microservices environments.
- Participated in architecture, development, testing, deployment and production support.

## Important Engineering Considerations

### Idempotency

A synchronization event may be delivered more than once, so the consumer should safely process duplicate messages.

### Failure Handling

Failed messages should be retried and eventually moved to a dead-letter mechanism where appropriate.

### Observability

Message processing should be logged and monitored so failures can be diagnosed without inspecting production data manually.

## Confidentiality

This is a public architecture case study. It does not include the original production source code or private platform details.
