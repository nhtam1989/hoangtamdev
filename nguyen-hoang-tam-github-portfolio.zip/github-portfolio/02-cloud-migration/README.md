# AWS EC2 → Viettel Cloud Migration

## Overview

A production infrastructure migration case study from AWS EC2 to Viettel Cloud.

The main objective was to move the production environment while keeping downtime as low as possible.

## Existing Environment

```text
AWS EC2
  |
  +-- Docker
  +-- Nginx
  +-- Node.js API
  +-- MongoDB
  +-- Redis
  +-- Elasticsearch
```

## Target Environment

```text
Viettel Cloud
  |
  +-- Docker
  +-- Nginx
  +-- Node.js API
  +-- MongoDB
  +-- Redis
  +-- Elasticsearch
```

## Migration Approach

1. Inventory existing services and dependencies.
2. Review environment variables and configuration.
3. Prepare the new cloud environment.
4. Install and configure Docker, Nginx, MongoDB, Redis and Elasticsearch.
5. Build and deploy application containers.
6. Configure CI/CD with GitHub Actions.
7. Back up and synchronize production data.
8. Test application and integrations.
9. Perform production cutover.
10. Monitor the new environment.
11. Keep the previous environment available as a rollback option.

## Key Challenge

The application was already running in production, so the migration could not simply stop the system for a long period.

The focus was therefore on preparation, validation, controlled cutover, monitoring and rollback planning.

## Result

- Production infrastructure migrated with minimal downtime.
- Deployment became automated through GitHub Actions and Docker.
- Deployment time was reduced by approximately 80%.

## Confidentiality

This repository is an architecture and migration case study. It does not contain production configuration, credentials or proprietary infrastructure code.
