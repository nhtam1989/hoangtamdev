# Database & API Performance Optimization

## Overview

A performance optimization case study based on production work across e-commerce and community platforms.

The focus was identifying slow database queries and improving API response time through query and indexing optimization.

## Investigation Process

```text
Slow API
   |
   v
Measure response time
   |
   v
Inspect SQL / MongoDB query
   |
   v
EXPLAIN / Query Analysis
   |
   v
Review indexes
   |
   v
Optimize query
   |
   v
Benchmark
   |
   v
Monitor production
```

## Areas I Analyze

- Query execution plan
- Full table / collection scans
- Index usage
- Composite indexes
- Number of returned rows
- Sorting and filtering
- Join complexity
- N+1 queries
- Pagination
- Redis caching opportunities
- Elasticsearch for search-heavy workloads

## Production Examples

### MongoDB

Product listing API response time was reduced from over 2 seconds to under 1 second by optimizing queries and indexing strategies.

### MySQL

Search API response time was reduced from over 3 seconds to approximately 1 second through query and index optimization.

## Engineering Principle

I don't add indexes blindly. I first identify the real query pattern, inspect the execution plan, benchmark the change and then consider the impact on write performance and storage.

## Confidentiality

This repository contains only a technical case study and does not contain proprietary queries, schemas or production data.
